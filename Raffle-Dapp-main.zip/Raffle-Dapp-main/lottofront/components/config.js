export const lotterycontract = "0xA2090Bccdd80Edf0eF9d7651A3324ec3Cba1eA46";
export const erc20contract = "0x4eCbbb31f25b5CE1500A69e6E48bd93927145000";
